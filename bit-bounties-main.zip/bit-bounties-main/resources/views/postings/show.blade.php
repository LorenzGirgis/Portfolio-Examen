<x-app-layout>
    <x-navbar></x-navbar>
    <body class="bg-gray-100">
        <div class="container mx-auto py-6 px-4">
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h1 class="text-2xl font-bold mb-4">{{ $posting->title }}</h1>
                <p class="text-gray-700 mb-4">{{ $posting->description }}</p>
                <p class="text-gray-600 mb-4">Posted by: {{ $posting->company->name }}</p>
                
                <h2 class="text-xl font-semibold mb-2">Tests</h2>
                @if($posting->tests->isEmpty())
                    <p class="text-gray-700">No tests available for this posting.</p>
                @else
                    <ul class="list-disc pl-5">
                        @foreach($posting->tests as $test)
                            <li class="mb-2">
                                <h3 class="font-semibold">{{ $test->title }}</h3>
                                <p class="text-gray-700">Desription: {{ $test->description }}</p>
                                <p class="text-gray-600">Duration: {{ $test->duration }}</p>
                            </li>
                            <button class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-1 px-2 rounded-md transition duration-300">Start this test</button>
                        @endforeach
                    </ul>
                @endif
  
                <a href="{{ route('dashboard') }}" class="text-blue-500 hover:underline mt-4 block">Back to Postings</a>
            </div>
        </div>
    </body>
  </x-app-layout>
  