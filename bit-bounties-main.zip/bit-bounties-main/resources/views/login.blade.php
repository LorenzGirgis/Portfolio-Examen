<x-app-layout>
<section class="bg-gray-50 dark:bg-gray-900">
  <div class="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0">
      <a href="/" class="flex items-center mb-6 text-2xl font-semibold text-gray-900 dark:text-white">
        <p>Bit Bounties</p>
      </a>
      <div class="w-full bg-white rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
          <div class="p-6 space-y-4 md:space-y-6 sm:p-8">
              <h1 class="text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl dark:text-white">
            Login
              </h1>
              <form class="space-y-4 md:space-y-6" action="{{ route('login') }}" method="POST">
                @csrf   
                <div>
                      <label for="email" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Email</label>
                      <input type="email" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required="">
                  </div>
                  <div>
                      <label for="password" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Password</label>
                      <input type="password" name="password" id="password" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required="">
                  </div>
                  <div class="flex items-center justify-between">
                      </div>
                      <a href="" class="text-sm font-medium text-primary-600 hover:underline  text-white -primary-500">Forgot password?</a>
                  <button type="submit" class="w-full text-white bg-primary-600 hover:bg-gray-600 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-4 py-2 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">Login</button>
                </form>
                  <div>
                    <a href="/auth/redirect" class="flex items-center justify-center text-white bg-gray-900 hover:bg-gray-600 focus:ring-4 focus:outline-none focus:ring-gray-300 font-medium rounded-lg text-sm px-4 py-2 text-center dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700">
                        <svg class="w-4 h-4 mr-2" aria-hidden="true" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 2a10 10 0 00-3.16 19.48c.5.09.68-.22.68-.48v-1.69c-2.78.6-3.37-1.34-3.37-1.34-.45-1.15-1.11-1.46-1.11-1.46-.91-.62.07-.61.07-.61 1 .07 1.52 1.04 1.52 1.04.89 1.52 2.34 1.08 2.91.83.09-.64.35-1.08.63-1.33-2.22-.25-4.56-1.11-4.56-4.94 0-1.09.39-1.99 1.02-2.7-.1-.25-.44-1.27.1-2.65 0 0 .83-.27 2.73 1.02A9.48 9.48 0 0112 6.8c.84 0 1.68.11 2.47.33 1.9-1.29 2.73-1.02 2.73-1.02.54 1.38.2 2.4.1 2.65.63.71 1.02 1.61 1.02 2.7 0 3.85-2.35 4.68-4.59 4.92.36.31.68.91.68 1.83v2.71c0 .27.18.59.69.48A10 10 0 0012 2z"></path>
                        </svg>
                        Login with GitHub
                      </a>
                </div>  
                  <p class="text-sm font-light text-gray-500 dark:text-gray-400">
                      Don’t have an account yet? <a href="register" class="font-medium text-primary-600 hover:underline dark:text-primary-500">Register</a>
                  </p>
                  <p class="text-sm font-light text-gray-500 dark:text-gray-400">
                    Are you a company? 
                    <a href="/dashboard" class="font-medium text-primary-600 hover:underline dark:text-primary-500" aria-label="Company Registration Page">
                        Login Here
                    </a>
                </p>                
          </div>
      </div>
  </div>
</section>
</html>
</x-app-layout>
