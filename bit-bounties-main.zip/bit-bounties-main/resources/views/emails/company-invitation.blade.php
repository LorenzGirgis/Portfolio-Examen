<x-mail::message>
You have been invited to join the <b>{{ $company }}</b> company on {{ config('app.name') }}

To accept the invitation and create an account, click the button below:

<x-mail::button :url="$acceptUrl">
{{ __('Create Account') }}
</x-mail::button>

{{ __('If you did not expect to receive an invitation to this team, you may discard this') }}
</x-mail::message>
