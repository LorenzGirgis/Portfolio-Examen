<x-app-layout>
    <x-navbar></x-navbar>
    <body class="bg-gray-100">
        <div class="container mx-auto py-6 px-4">
            <h1 class="text-2xl font-bold mb-6">Job Postings</h1>
            @if ($postings->isEmpty())
                <p class="text-gray-700">No postings available.</p>
            @else
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    @foreach ($postings as $posting)
                        <div class="bg-white p-4 rounded-lg shadow-md">
                            <h2 class="text-xl font-semibold mb-2">{{ $posting->title }}</h2>
                            <p class="text-gray-700">{{ $posting->description }}</p>
                            <a href="{{ route('postings.show', $posting) }}" class="text-blue-500 hover:underline mt-4 block">View Tests</a>
                        </div>
                    @endforeach
                </div>
            @endif
        </div>
    </body>
</x-app-layout>
