<div class="min-h-screen flex flex-col">
    <header class="bg-bounties-light shadow-lg flex justify-between items-center">
        <p class="text-white">Bit Bounties</p>
        <p class="w-20 h-10 mr-1" src="" alt="">  
        <div class="relative">
            @auth
                <button class="text-white font-semibold focus:outline-none" id="userDropdown">
                    {{ Auth::user()->name }} <span class="">&#x25BE;</span>
                </button>
                <ul class="absolute right-0 mt-2 w-32 bg-white border border-gray-200 rounded-lg shadow-md z-10 hidden" id="dropdownMenu">
                    <li><a href="{{ route('dashboard') }}" class="block px-4 py-2 text-gray-800 hover:bg-blue-100 hover:text-bounties-dark transition-colors duration-300">Dashboard</a></li>
                    @if (Auth::user()->role == 'admin')
                    <li><a href="{{ route('admin') }}" class="block px-4 py-2 text-gray-800 hover:bg-blue-100 hover:text-bounties-dark transition-colors duration-300">Admin</a></li>
                @endif
                    <li><a href="{{ route('profile') }}" class="block px-4 py-2 text-gray-800 hover:bg-blue-100 hover:text-bounties-dark transition-colors duration-300">Profile</a></li>
                    <li><a href="{{ route('logout') }}" class="block px-4 py-2 text-gray-800 hover:bg-blue-100 hover:text-bounties-dark transition-colors duration-300">Logout</a></li>
                </ul>
            @endauth
            @guest
                <a href="{{ route('login') }}"
                    class="text-bounties-gray hover:text-white transition-colors duration-300">Login</a>
            @endguest
        </div>
    </header>
    <script>
        document.addEventListener('click', function (event) {
            var isClickInside = document.querySelector('.relative').contains(event.target);

            if (!isClickInside) {
                var dropdown = document.getElementById('dropdownMenu');
                dropdown.classList.add('hidden');
            }
        });
        document.getElementById('userDropdown').addEventListener('click', function () {
            var dropdown = document.getElementById('dropdownMenu');
            dropdown.classList.toggle('hidden');
        });
    </script>