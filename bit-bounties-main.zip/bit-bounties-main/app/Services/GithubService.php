<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class GithubService
{
    protected $token;

    // WIP
    private $owner = 'Frisobron';

    public function __construct()
    {
        $this->token = config('github.token');
    }

    public function createRepository(string $slug): array
    {
        $response = Http::withHeaders([
            'Authorization' => "token {$this->token}",
            'Accept' => 'application/vnd.github.v3+json',
        ])->post('https://api.github.com/user/repos', [
            'name' => $slug,
            'private' => true,
        ]);

        if (array_key_exists('errors', $response->json())) {
            return ['error' => $response->json()['errors'][0]['message']];
        }

        return $response->json();
    }

    // WIP
    public function createOrUpdateFile($owner, $repository, $path, $message, $content): array
    {
        $response = Http::withHeaders([
            'Authorization' => "token {$this->token}",
            'Accept' => 'application/vnd.github+json',
        ])->put("https://api.github.com/repos/{$owner}/{$repository}/contents/{$path}", [
            'owner' => $owner,
            'repository' => $repository,
            'path' => $path,
            'message' => $message,
            'content' => base64_encode($content),
        ]);

        return $response->json();
    }

    public function deleteRepository(string $repository)
    {
        $response = Http::withHeaders([
            'Authorization' => "token {$this->token}",
            'Accept' => 'application/vnd.github+json',
        ])->delete("https://api.github.com/repos/$this->owner/$repository", [
            'owner' => $this->owner,
            'repository' => $repository,
        ]);

        if (!empty($response->json())) {
            if (array_key_exists('message', $response->json())) {
                return ['error' => $response->json()['message']];
            }
        }

        return $response->json();
    }

    // WIP
    // public function forkRepository($owner, $repository): array
    // {
    //     $response = Http::withHeaders([
    //         'Authorization' => "token {$this->token}",
    //         'Accept' => 'application/vnd.github+json',
    //     ])->post("https://api.github.com/repos/{$owner}/{$repository}/forks", [
    //         'owner' => $owner,
    //         'repository' => $repository,
    //     ]);

    //     return $response->json();
    // }
}
