<?php
namespace App\Http\Controllers;

use App\Models\Posting;
use Illuminate\Http\Request;

class PostingController extends Controller
{
    public function index()
    {
        $postings = Posting::with('company')->where('is_active', true)->get();
        return view('dashboard', compact('postings'));
    }

    public function show(Posting $posting)
    {
        $posting->load('tests'); // Eager load tests
        return view('postings.show', compact('posting'));
    }
}
