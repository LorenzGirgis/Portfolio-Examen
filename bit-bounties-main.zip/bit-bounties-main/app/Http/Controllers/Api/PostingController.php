<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PostingResource;
use App\Models\Posting;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class PostingController extends Controller
{
    public function index(): AnonymousResourceCollection
    {
        return PostingResource::collection(Posting::isActive()->get());
    }

    public function show(Posting $posting)
    {
        return new PostingResource($posting);
    }
}
