<?php

namespace App\Filament\Dashboard\Resources\PostingResource\Pages;

use App\Filament\Dashboard\Resources\PostingResource;
use Filament\Actions\DeleteAction;
use Filament\Resources\Pages\EditRecord;

class EditPosting extends EditRecord
{
    protected static string $resource = PostingResource::class;

    protected function getHeaderActions(): array
    {
        return [
            DeleteAction::make(),
        ];
    }
}
