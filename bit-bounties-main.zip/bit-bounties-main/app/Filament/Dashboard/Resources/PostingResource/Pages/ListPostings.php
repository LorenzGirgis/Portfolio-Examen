<?php

namespace App\Filament\Dashboard\Resources\PostingResource\Pages;

use App\Filament\Dashboard\Resources\PostingResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;

class ListPostings extends ListRecords
{
    protected static string $resource = PostingResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make(),
        ];
    }
}
