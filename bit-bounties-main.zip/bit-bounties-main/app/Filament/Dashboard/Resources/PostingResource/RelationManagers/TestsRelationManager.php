<?php

namespace App\Filament\Dashboard\Resources\PostingResource\RelationManagers;

use App\Models\Test;
use App\Services\GithubService;
use Filament\Facades\Filament;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\MarkdownEditor;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\TimePicker;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Form;
use Filament\Forms\Set;
use Filament\Notifications\Notification;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables\Actions\BulkActionGroup;
use Filament\Tables\Actions\CreateAction;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\DeleteBulkAction;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Enums\FiltersLayout;
use Filament\Tables\Filters\QueryBuilder;
use Filament\Tables\Filters\QueryBuilder\Constraints\BooleanConstraint;
use Filament\Tables\Filters\QueryBuilder\Constraints\TextConstraint;
use Filament\Tables\Table;
use Illuminate\Support\Str;

class TestsRelationManager extends RelationManager
{
    protected static string $relationship = 'tests';

    protected static ?string $recordTitleAttribute = 'title';

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Hidden::make('company_id')
                    ->default(Filament::getTenant()->getKey()),

                TextInput::make('title')
                    ->required()
                    ->maxLength(255)
                    ->live(onBlur: true)
                    ->afterStateUpdated(function (string $operation, $state, Set $set) {
                        if ($operation !== 'create') {
                            return;
                        }

                        $set('slug', Str::slug($state));
                    }),

                TextInput::make('slug')
                    ->disabled()
                    ->dehydrated()
                    ->required()
                    ->maxLength(255)
                    ->unique(Test::class, 'slug', ignoreRecord: true),

                MarkdownEditor::make('description')
                    ->required()
                    ->columnSpanFull(),

                TimePicker::make('duration')
                    ->columnSpanFull(),

                Toggle::make('is_active')
                    ->label('Visible')
                    ->default(true),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('title')
            ->columns([
                TextColumn::make('title')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('slug')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('duration')
                    ->time()
                    ->placeholder('No duration')
                    ->sortable(),

                IconColumn::make('is_active')
                    ->label('Visible')
                    ->boolean()
                    ->sortable(),

                TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),

                TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                QueryBuilder::make()
                    ->constraints([
                        TextConstraint::make('title'),
                        TextConstraint::make('slug'),
                        BooleanConstraint::make('is_visible')
                            ->label('Visibility'),
                    ])
                    ->constraintPickerColumns(2),
            ], layout: FiltersLayout::AboveContentCollapsible)
            ->deferFilters()
            ->headerActions([
                CreateAction::make()
                    ->before(function (CreateAction $action, array $data) {
                        $github = new GithubService();
                        $repository = $github->createRepository($data['slug']);

                        if (array_key_exists('error', $repository)) {
                            Notification::make()
                                ->danger()
                                ->title('Repository creation failed!')
                                ->body('Please use a different title/slug.')
                                ->send();
                        
                            $action->halt();
                        }

                        Notification::make()
                            ->success()
                            ->title('Repository created!')
                            ->send();
                    }),
            ])
            ->actions([
                EditAction::make(),
                DeleteAction::make()
                    ->before(function (DeleteAction $action, Test $test) {
                        $github = new GithubService();
                        $repository = $github->deleteRepository($test->slug);

                        if (!empty($repository)) {
                            if (array_key_exists('error', $repository)) {
                                Notification::make()
                                    ->danger()
                                    ->title('Repository deletion failed!')
                                    ->body('Please contact support.')
                                    ->send();
                            }

                            $action->halt();
                        }

                        Notification::make()
                            ->success()
                            ->title('Repository deleted!')
                            ->send();
                    }),
            ])
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make()
                        // WIP
                        ->after(function (array $tests) {
                            dd($tests);
                            $owner = "FrisoBron";

                            $github = new GithubService();
                            foreach ($tests as $test) {
                                $github->deleteRepository($owner, $test->slug);
                            }
                        })
                ]),
            ]);
    }
}
