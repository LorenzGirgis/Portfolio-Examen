<?php

namespace App\Filament\Dashboard\Resources\TestResource\Pages;

use App\Filament\Dashboard\Resources\TestResource;
use App\Models\Test;
use App\Services\GithubService;
use Filament\Actions\DeleteAction;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\EditRecord;

class EditTest extends EditRecord
{
    protected static string $resource = TestResource::class;

    protected function getHeaderActions(): array
    {
        return [
            DeleteAction::make()
                ->before(function (Test $test) {
                    $github = new GithubService();
                    $repository = $github->deleteRepository($test->slug);

                    if (!empty($repository)) {
                        if (array_key_exists('error', $repository)) {
                            Notification::make()
                                ->danger()
                                ->title('Repository deletion failed!')
                                ->body('Please contact support.')
                                ->send();
                        }

                        $this->halt();
                    }

                    Notification::make()
                        ->success()
                        ->title('Repository deleted!')
                        ->send();
                }),
        ];
    }
}
