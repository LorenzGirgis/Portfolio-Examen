<?php

namespace App\Filament\Dashboard\Resources\TestResource\Pages;

use App\Filament\Dashboard\Resources\TestResource;
use App\Services\GithubService;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\CreateRecord;

class CreateTest extends CreateRecord
{
    protected static string $resource = TestResource::class;

    protected function beforeCreate(): void
    {
        $data = $this->data;

        $github = new GithubService();
        $repository = $github->createRepository($data['slug']);

        if (array_key_exists('error', $repository)) {
            Notification::make()
                ->danger()
                ->title('Repository creation failed!')
                ->body('Please use a different title/slug.')
                ->send();
        
            $this->halt();
        }

        Notification::make()
            ->success()
            ->title('Repository created!')
            ->send();
    }
}
