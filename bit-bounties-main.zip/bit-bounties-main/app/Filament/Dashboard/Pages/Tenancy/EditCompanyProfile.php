<?php

namespace App\Filament\Dashboard\Pages\Tenancy;

use Filament\Forms\Components\Grid;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Pages\Tenancy\EditTenantProfile;
use Parfaitementweb\FilamentCountryField\Forms\Components\Country;
use Ysfkaya\FilamentPhoneInput\Forms\PhoneInput;

class EditCompanyProfile extends EditTenantProfile
{
    public static function getLabel(): string
    {
        return 'Company profile';
    }
 
    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('Information')
                    ->schema([
                        TextInput::make('name')
                            ->required()
                            ->maxLength(255),

                        TextInput::make('email')
                            ->required()
                            ->email()
                            ->maxLength(255),

                        PhoneInput::make('phone'),

                        TextInput::make('website')
                            ->prefix('https://')
                            ->maxLength(255),
                    ]),

                Section::make('Address')
                    ->schema([
                        Grid::make()
                            ->columns(4)
                            ->schema([
                                TextInput::make('street')
                                    ->columnSpan(['lg' => 3, 'sm' => 4]),
                
                                TextInput::make('postal_code')
                                    ->columnSpan(['lg' => 1, 'sm' => 4]),
                
                                TextInput::make('city')
                                    ->columnSpan(['lg' => 2, 'sm' => 4]),

                                Country::make('country')
                                    ->searchable()
                                    ->columnSpan(['lg' => 2, 'sm' => 4]),
                            ]),
                    ]),
            ]);
    }
}
