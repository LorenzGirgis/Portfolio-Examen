<?php

namespace App\Filament\Dashboard\Pages;

use App\Mail\CompanyInvitationMail;
use App\Models\Invitation;
use Filament\Actions\Action;
use Filament\Facades\Filament;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Illuminate\Support\Facades\Mail;

class Invitations extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-envelope';

    protected static string $view = 'filament.pages.invitations';

    protected function getHeaderActions(): array
    {
        return [
            Action::make('inviteUser')
                ->form([
                    TextInput::make('email')
                        ->email()
                        ->required(),
                ])
                ->action(function ($data) {
                    $tenant = Filament::getTenant()->getKey();

                    if (auth()->user()->email === $data['email']) {
                        Notification::make()
                            ->title('You cannot invite yourself!')
                            ->danger()
                            ->send();

                        return;
                    }

                    if (Invitation::where('email', $data['email'])->where('company_id', $tenant)->exists()) {
                        Notification::make()
                            ->title('User already invited!')
                            ->danger()
                            ->send();

                        return;
                    }

                    if (Filament::getTenant()->members()->pluck('email')->contains($data['email'])) {
                        Notification::make()
                            ->title('User already in company!')
                            ->danger()
                            ->send();

                        return;
                    }

                    $invitation = Invitation::create([
                        'company_id' => $tenant,
                        'email' => $data['email']
                    ]);

                    Mail::to($invitation->email)->send(new CompanyInvitationMail($invitation));

                    Notification::make()
                        ->title('User invited successfully!')
                        ->success()
                        ->send();
                })
        ];
    }
}
