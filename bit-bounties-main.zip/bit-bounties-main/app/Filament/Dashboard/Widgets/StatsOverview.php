<?php

namespace App\Filament\Dashboard\Widgets;

use App\Models\Posting;
use App\Models\Test;
use Filament\Facades\Filament;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class StatsOverview extends BaseWidget
{
    protected function getStats(): array
    {
        $tenant = Filament::getTenant()->getKey();
        $postings = Posting::where('company_id', $tenant)->count();
        $tests = Test::where('company_id', $tenant)->count();

        return [
            // WIP
            Stat::make('Total Employees', 0),

            Stat::make('Total Postings', $postings),

            Stat::make('Total Tests', $tests),
        ];
    }
}
