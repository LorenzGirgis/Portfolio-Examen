<?php

namespace App\Observers;

use App\Models\Invitation;
use App\Models\User;
use Filament\Notifications\Actions\Action;
use Filament\Notifications\Notification;
use Illuminate\Support\Facades\URL;

class InvitationObserver
{
    public function created(Invitation $invitation): void
    {
        if ($user = User::where('email', $invitation->email)->first()) {
            Notification::make()
                ->title('You have been invited to join ' . $invitation->company->name . '.')
                ->actions([
                    Action::make('Accept')
                        ->url(URL::signedRoute(
                            'invitation.accept',
                            ['invitation' => $invitation],
                        ))
                        ->button()
                        ->markAsRead(),

                    // TODO (Lorenz): Add a decline action
                ])
                ->sendToDatabase($user);
        }
    }
}
