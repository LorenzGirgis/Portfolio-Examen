<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Test extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'posting_id',
        'title',
        'slug',
        'description',
        'duration',
        'repository',
        'is_active',
    ];

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function posting(): BelongsTo
    {
        return $this->belongsTo(Posting::class);
    }
}
