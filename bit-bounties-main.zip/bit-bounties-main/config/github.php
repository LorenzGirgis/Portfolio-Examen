<?php

return [

    'token' => env('GITHUB_TOKEN'),

];
