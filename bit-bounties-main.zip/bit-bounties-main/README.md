# Bit Bounties

## Algemene informatie
 Naam opdrachtgever: Joris Schelfhout


Project manager: Ties Noordhuis


Naam project: Bit Bounties

### Contributors

- Lorenz Girgis.
- Ryan Sutrisno.
- Jay Cheung.
- Joel Boafo.
- Devran Yusuf Kehya.

## Projectbeschrijving

Het verbeteren van het huidige NexEd job-board door een platform te bieden waar bedrijven technische tests (bounties) kunnen plaatsen. Studenten kunnen door het succesvol voltooien van deze tests een stageplek verdienen.

 Met opdracht van onze klant Joris Schelfhout en onze projectbegeleider Ties Noordhuis, is het uiteindelijke doel van dit project het huidige Nexed Jobboard te vervangen met een meer user-friendly en efficient jobboard platform.

## Up and running

Het project kan worden gerunned als volgt:
1. Clone de [repository](https://github.com/praxand/bit-bounties).
2. installeer dependencies: `npm install`.
In sommige gevallen kan het zo zijn dat er ook
`composer install` moet worden gerunned.

3. kopieer de `.env.example` file en rename deze copy `.env`. Let op! Het is belangrijk dat je de `.env` file niet aanpast.
4. run `php artisan key:generate` en daarna `php artisan migrate`. Dit zorgt ervoor dat de database word gemigreerd en de key zorgt ervoor dat je de applicatie kan openen.
5. run `php artisan serve` en `ctrl + left mouse click` op de link die verschijnt in je terminal of kopieer deze link in je browser om de applicatie te openen.
6. ga naar `http://127.0.0.1:8000/admin`. Als het goed is, kom je op een login pagina terecht. Vanaf hier kun je de applicatie gebruiken.

### Talen

- TypeScript
- HTML
- CSS
- PHP

### Frameworks

- Next.js (React)
- TailwindCSS
- OAuth 2.0
- Axios
- react-feather
- Formik
- Laravel
- Filament
- MySQL
