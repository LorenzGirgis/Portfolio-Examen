<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class PostingFactory extends Factory
{
    public function definition(): array
    {
        return [
            'title' => fake()->jobTitle(),
            'slug' => fake()->unique()->slug(),
            'description' => fake()->paragraph(),
            'is_active' => fake()->boolean(),
        ];
    }
}
