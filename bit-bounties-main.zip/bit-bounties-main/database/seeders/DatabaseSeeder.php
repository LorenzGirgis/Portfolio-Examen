<?php

namespace Database\Seeders;

use App\Models\Posting;
use App\Models\Test;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::factory()->create([
            'email' => 'test@example.com',
            'password' => bcrypt('password'),
        ]);

        User::factory(9)
            ->hasCompanies(1)
            ->create()
            ->each(function ($user) {
            $user->companies->each(function ($company) {
                $company->postings()->saveMany(Posting::factory(5)->make())
                ->each(function ($posting) use ($company) {
                    Test::factory(3)->create([
                    'posting_id' => $posting->id,
                    'company_id' => $company->id,
                    ]);
                });
            });
            });
}
}
