// tailwind.config.js
module.exports = {
  content: [
    "./resources/**/*.blade.php",
    "./resources/**/*.js",
    "./resources/**/*.vue",
  ],
  theme: {
    extend: {
      colors: {
        'bounties-dark': '#121212',
        'bounties-light': '#282828',
        'bounties-green': '#1DB954',
        'bounties-gray': '#b3b3b3',
      },
    },
  },
  plugins: [],
}