<?php
// run de tests met het commando: ./vendor/bin/pest tests/Feature/ApiTest.php

// test 1
// Deze test simuleert een API call via een HTTP POST request en postman om te checken of er een repository kan worden gemaakt.
// Er word gechecked of de response JSON een specifieke structuur terug geeft die we als voorbeeld nemen van de official github API.
it('ensures the platform can create a repository', function () {
    $response = $this->postJson(route('repository.create'), [
        'name' => 'testrepo',
        'private' => true,
    ]);

    $response->assertStatus(200);
    $response->assertJsonStructure([
        'id',
        'name',
        'private',
    ]);
});

//test 2
// Deze test simuleert een API call via een HTTP PUT request en postman om te checken of er een student kan worden toegevoegd aan de zojuist gemaakte repository.
// Er word gechecked of de response JSON een specifieke structuur terug geeft die we als voorbeeld nemen van de official github API.
it('ensures the platform can add a student to the repository', function () {
    $response = $this->putJson(route('repository.addCollaborator'), [
        'owner' => 'FrisoBron',
        'repository' => 'testrepo',
        'username' => 'LorenzGirgis',
    ]);

    $response->assertStatus(200);
    $response->assertJsonStructure([
        'id',
        'repository' => [
            'id',
            'name',
            'full_name',
            'private',
            'owner',
        ],
    ]);
});

//test 3
// Deze test simuleert een API call via een HTTP DELETE request en postman om te checken of de zojuist gemaakte repository kan worden verwijderd.
// Er word gechecked of de response JSON een specifieke structuur terug geeft die we als voorbeeld nemen van de official github API.
it('ensures the platform can delete a repository', function () {
    $response = $this->deleteJson(route('repository.delete'), [
        'owner' => 'FrisoBron',
        'repository' => 'testrepo',
    ]);


    $response->assertStatus(204);
    $response->assertDontSee('testrepo');
});
