<?php

use App\Models\User;
//test 10

//kijkt of de database correct word ge-seed
it('seeds the database correctly', function () {
    $this->seed();

    $this->assertDatabaseHas('users', [
        'first_name' => 'Test',
        'last_name' => 'User',
        'email' => 'test@example.com',
    ]);

    $user = User::where('email', 'test@example.com')->first();

    $this->assertNotNull($user->company);
    $this->assertCount(3, $user->tests);
});
