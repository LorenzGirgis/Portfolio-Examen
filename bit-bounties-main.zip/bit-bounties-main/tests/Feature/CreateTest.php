<!-- <?php

        use Tests\TestCase;
        use App\Models\Test;
        use App\Models\User;
        use Filament\Filament;
        use App\Filament\Resources\TestResource\Pages\CreateTest;
        use App\Models\Company;
        use Illuminate\Routing\RouteRegistrar;
        use function Pest\Laravel\{post};
//test 6

        it('can create a test correctly', function () {

            $user = User::factory()->create();
            $newData = $user->tests()->create([
                'user_id' => $user->id,
                'title' => fake()->word(),
                'slug' => fake()->word(),
                'description' => fake()->sentence(),
                'duration' => fake()->time(),
                'repository' => fake()->url(),
                'is_active' => fake()->boolean(),
            ]);

            $response = $this->post(url('/admin/tests/create'), [
                'user_id' => $user->id,
                'title' => $newData->title,
                'slug' => $newData->slug,
                'description' => $newData->description,
                'duration' => $newData->duration,
                'repository' => $newData->repository,
                'is_active' => $newData->is_active,
            ]);

            $response = $user->tests()->create([

            ]);
            $response = $this->post('filament.admin.pages.tests.create', [
                'title' => $newData->title,
                'slug' => $newData->slug,
                'description' => $newData->description,
                'duration' => $newData->duration,
                'repository' => $newData->repository,
                'is_active' => $newData->is_active,
            ]);

            $this->assertDatabaseHas('tests', [
                'title' => $newData->title,
                'slug' => $newData->slug,
                'description' => $newData->description,
                'duration' => $newData->duration,
                'repository' => $newData->repository,
                'is_active' => $newData->is_active,
            ]);

        });
