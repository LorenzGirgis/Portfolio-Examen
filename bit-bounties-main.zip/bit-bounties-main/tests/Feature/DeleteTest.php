<?php

use App\Filament\Resources\TestResource\Pages;
//test 7

it('Deletes the test correctly', function () {
    $this->seed();
    $response = $this->delete(url('/admin/tests/1/delete'));

    $response->assertStatus(302);
});