<?php

use App\Models\User;

//test 4
it('ensures the user can register', function () {
    $user = User::factory()->make();

    $this->post(url('admin/register'), [
        'first_name' => $user->first_name,
        'last_name' => $user->last_name,
        'email' => $user->email,
        'password' => 'password',
        'password_confirmation' => 'password',
    ]);

    $this->assertDatabaseHas('users', [
        'first_name' => $user->first_name,
        'last_name' => $user->last_name,
        'email' => $user->email,
        'password' => 'password',
    ]);
});

//test 5
it('ensures the user can login', function () {
    $user = User::factory()->create([
        'password' => bcrypt('password'),
    ]);

    $this->post(url('admin/login'), [
        'email' => $user->email,
        'password' => 'password',
    ]);

    $this->assertAuthenticated();
});