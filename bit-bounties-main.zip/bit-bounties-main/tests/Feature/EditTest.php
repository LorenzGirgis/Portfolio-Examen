<?php

use App\Models\User;
//test 8

it('Edits the test correctly', function () {

    $this->actingAs(User::factory()->create());
    $this->seed();
    $response = $this->put(url('/admin/tests/1/edit'), [
       'title' => 'Test',
       'slug' => 'Test',
       'description' => 'Test',
       'duration' => 'Test',
       'repository' => 'Test',
       'is_active' => 'Test',
     ]);

     $response->assertStatus(302);
});