<?php

//test 9

//kijkt of de pagina's correct laden en zichtbaar zijn voor studenten als dit niet hoort
it('ensures that students cant see the admin pages or the company pages', function () {
     // Maak een gebruiker aan met een admin rol
     $admin = User::factory()->create(['role' => 'admin']);

     // Maak een gebruiker aan met een reguliere rol
     $user = User::factory()->create(['role' => 'user']);
 
     // Log in als admin en probeer de beveiligde route te openen
     $this->actingAs($admin);
     $response = $this->get('/admin/bounties');
     $response->assertStatus(200); // Admin zou toegang moeten hebben
 
     // Log in als reguliere gebruiker en probeer dezelfde route te openen
     $this->actingAs($user);
     $response = $this->get('/admin/bounties');
     $response->assertStatus(403); // Reguliere gebruiker mag geen toegang hebben
});