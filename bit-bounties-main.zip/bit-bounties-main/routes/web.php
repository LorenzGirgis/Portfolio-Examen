<?php

use App\Livewire\AcceptInvitation;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\PostingController;
use App\Http\Controllers\GithubAuthController;
use App\Models\User;


Route::middleware('signed')
    ->get('invitation/{invitation}/accept', AcceptInvitation::class)
    ->name('invitation.accept');


Route::middleware(['guest'])->group(function () {
    Route::get('/auth/redirect', [GithubAuthController::class, 'redirectToProvider']);
    Route::get('/auth/callback', [GithubAuthController::class, 'handleProviderCallback']);
    Route::get('/login', [AuthController::class, 'login'])->name('login');
    Route::get('/register', [AuthController::class, 'register'])->name('register');
    Route::post('/login', [AuthController::class, 'loginpost'])->name('login');
    Route::post('/register', [AuthController::class, 'registerpost'])->name('register');
});

Route::middleware(['auth'])->group(function () {
    Route::get('/logout', [AuthController::class, 'logout'])->name('logout');
    Route::get('/profile', [ProfileController::class, 'profile'])->name('profile');
    Route::get('/profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::delete('/profile/delete', [ProfileController::class, 'delete'])->name('profile.delete');
    Route::put('/profile/update', [ProfileController::class, 'update'])->name('profile.update');
    Route::post('/profile/store', [ProfileController::class, 'store'])->name('profile.store');
    Route::get('/password', [ProfileController::class, 'password'])->name('password');
    Route::put('/password/update', [ProfileController::class, 'updatePassword'])->name('password.update');
    Route::put('/photo/update', [ProfileController::class, 'updatePhoto'])->name('photo.update');
    Route::get('/', [PostingController::class, 'index'])->name('dashboard');
    Route::get('/postings/{posting}', [PostingController::class, 'show'])->name('postings.show');
});
// TODO (Lorenz): Add a decline action
