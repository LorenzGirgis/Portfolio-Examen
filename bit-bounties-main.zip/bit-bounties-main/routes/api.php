<?php

use App\Http\Controllers\Api\CompanyController;
use App\Http\Controllers\Api\PostingController;
use App\Http\Controllers\Api\TestController;
use Illuminate\Support\Facades\Route;


Route::get('/tests', [TestController::class, 'index']);
Route::get('/tests/{test}', [TestController::class, 'show']);

Route::get('/companies', [CompanyController::class, 'index']);
Route::get('/companies/{company}', [CompanyController::class, 'show']);

Route::get('/postings', [PostingController::class, 'index']);
Route::get('/postings/{posting}', [PostingController::class, 'show']);

